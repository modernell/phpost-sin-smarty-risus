-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 18-08-2012 a las 18:22:38
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `risus`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `f_comentarios`
-- 

CREATE TABLE `f_comentarios` (
  `cid` int(11) NOT NULL auto_increment,
  `c_foto_id` int(11) NOT NULL,
  `c_user` int(11) NOT NULL,
  `c_date` int(10) NOT NULL,
  `c_body` text NOT NULL,
  `c_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `f_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `f_fotos`
-- 

CREATE TABLE `f_fotos` (
  `foto_id` int(11) NOT NULL auto_increment,
  `f_title` varchar(40) NOT NULL,
  `f_date` int(10) NOT NULL,
  `f_description` text NOT NULL,
  `f_url` varchar(200) NOT NULL,
  `f_user` int(11) NOT NULL,
  `f_closed` int(1) NOT NULL default '0',
  `f_visitas` int(1) NOT NULL default '0',
  `f_votos_pos` int(3) NOT NULL default '0',
  `f_votos_neg` int(3) NOT NULL default '0',
  `f_status` int(1) NOT NULL default '0',
  `f_last` int(1) NOT NULL default '0',
  `f_hits` int(11) NOT NULL default '0',
  `f_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`foto_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `f_fotos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `f_votos`
-- 

CREATE TABLE `f_votos` (
  `vid` int(11) NOT NULL auto_increment,
  `v_foto_id` int(11) NOT NULL,
  `v_user` int(11) NOT NULL,
  `v_type` int(1) NOT NULL,
  `v_date` int(11) NOT NULL,
  PRIMARY KEY  (`vid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `f_votos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_borradores`
-- 

CREATE TABLE `p_borradores` (
  `bid` int(11) NOT NULL auto_increment,
  `b_user` int(11) NOT NULL,
  `b_date` int(10) NOT NULL,
  `b_title` varchar(60) NOT NULL,
  `b_body` text,
  `b_tags` varchar(128) default NULL,
  `b_category` int(4) NOT NULL,
  `b_private` int(1) NOT NULL default '0',
  `b_block_comments` int(1) NOT NULL default '0',
  `b_sponsored` int(1) NOT NULL default '0',
  `b_sticky` int(1) NOT NULL default '0',
  `b_smileys` int(1) NOT NULL,
  `b_visitantes` int(1) NOT NULL default '0',
  `b_post_id` int(11) NOT NULL default '0',
  `b_status` int(1) NOT NULL default '1',
  `b_causa` varchar(128) NOT NULL,
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `p_borradores`
-- 

INSERT INTO `p_borradores` VALUES (1, 1, 1345159763, 'Bienvenido a PHPost Risus', '[align=center][size=18]Este es el primer post de los miles que tendrá tu web  ;)  \r\n\r\nGracias por elegir a [url=http://www.phpost.net]PHPost[/url] como tu Link Sharing System.[/size][/align]', '', 30, 0, 0, 0, 0, 0, 0, 0, 2, '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_categorias`
-- 

CREATE TABLE `p_categorias` (
  `cid` int(11) NOT NULL auto_increment,
  `c_orden` int(11) NOT NULL,
  `c_nombre` varchar(32) NOT NULL,
  `c_seo` varchar(32) NOT NULL,
  `c_img` varchar(32) NOT NULL default 'comments.png',
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

-- 
-- Volcar la base de datos para la tabla `p_categorias`
-- 

INSERT INTO `p_categorias` VALUES (1, 1, 'Animaciones', 'animaciones', 'flash.png');
INSERT INTO `p_categorias` VALUES (2, 2, 'Apuntes y Monografías', 'apuntesymonografias', 'report.png');
INSERT INTO `p_categorias` VALUES (3, 3, 'Arte', 'arte', 'palette.png');
INSERT INTO `p_categorias` VALUES (4, 4, 'Autos y Motos', 'autosymotos', 'car.png');
INSERT INTO `p_categorias` VALUES (5, 5, 'Celulares', 'celulares', 'phone.png');
INSERT INTO `p_categorias` VALUES (6, 6, 'Ciencia y Educación', 'cienciayeducacion', 'lab.png');
INSERT INTO `p_categorias` VALUES (7, 7, 'Comics', 'comics', 'comic.png');
INSERT INTO `p_categorias` VALUES (8, 8, 'Deportes', 'deportes', 'sport.png');
INSERT INTO `p_categorias` VALUES (9, 9, 'Downloads', 'downloads', 'disk.png');
INSERT INTO `p_categorias` VALUES (10, 10, 'E-books y Tutoriales', 'ebooksytutoriales', 'ebook.png');
INSERT INTO `p_categorias` VALUES (11, 11, 'Ecología', 'ecologia', 'nature.png');
INSERT INTO `p_categorias` VALUES (12, 12, 'Economía y Negocios', 'economiaynegocios', 'economy.png');
INSERT INTO `p_categorias` VALUES (13, 13, 'Femme', 'femme', 'female.png');
INSERT INTO `p_categorias` VALUES (14, 14, 'Hazlo tu mismo', 'hazlotumismo', 'escuadra.png');
INSERT INTO `p_categorias` VALUES (15, 15, 'Humor', 'humor', 'humor.png');
INSERT INTO `p_categorias` VALUES (16, 16, 'Imágenes', 'imagenes', 'photo.png');
INSERT INTO `p_categorias` VALUES (17, 17, 'Info', 'info', 'book.png');
INSERT INTO `p_categorias` VALUES (18, 18, 'Juegos', 'juegos', 'controller.png');
INSERT INTO `p_categorias` VALUES (19, 19, 'Links', 'links', 'link.png');
INSERT INTO `p_categorias` VALUES (20, 20, 'Linux', 'linux', 'tux.png');
INSERT INTO `p_categorias` VALUES (21, 21, 'Mac', 'mac', 'mac.png');
INSERT INTO `p_categorias` VALUES (22, 22, 'Manga y Anime', 'mangayanime', 'manga.png');
INSERT INTO `p_categorias` VALUES (23, 23, 'Mascotas', 'mascotas', 'pet.png');
INSERT INTO `p_categorias` VALUES (24, 24, 'Música', 'musica', 'music.png');
INSERT INTO `p_categorias` VALUES (25, 25, 'Noticias', 'noticias', 'newspaper.png');
INSERT INTO `p_categorias` VALUES (26, 26, 'Off Topic', 'offtopic', 'comments.png');
INSERT INTO `p_categorias` VALUES (27, 27, 'Recetas y Cocina', 'recetasycocina', 'cake.png');
INSERT INTO `p_categorias` VALUES (28, 28, 'Salud y Bienestar', 'saludybienestar', 'heart.png');
INSERT INTO `p_categorias` VALUES (29, 29, 'Solidaridad', 'solidaridad', 'salva.png');
INSERT INTO `p_categorias` VALUES (30, 30, 'Social Posting', 'social posting', 'tscript.png');
INSERT INTO `p_categorias` VALUES (31, 31, 'Turismo', 'turismo', 'brujula.png');
INSERT INTO `p_categorias` VALUES (32, 32, 'TV, Peliculas y series', 'tvpeliculasyseries', 'tv.png');
INSERT INTO `p_categorias` VALUES (33, 33, 'Videos On-line', 'videosonline', 'film.png');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_comentarios`
-- 

CREATE TABLE `p_comentarios` (
  `cid` int(11) NOT NULL auto_increment,
  `c_post_id` int(11) NOT NULL,
  `c_user` int(11) NOT NULL,
  `c_date` int(10) NOT NULL,
  `c_body` text NOT NULL,
  `c_votos` int(3) NOT NULL default '0',
  `c_status` enum('0','1') NOT NULL default '0',
  `c_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `p_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_favoritos`
-- 

CREATE TABLE `p_favoritos` (
  `fav_id` int(11) NOT NULL auto_increment,
  `fav_user` int(11) NOT NULL,
  `fav_post_id` int(11) NOT NULL,
  `fav_date` int(10) NOT NULL,
  PRIMARY KEY  (`fav_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `p_favoritos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_posts`
-- 

CREATE TABLE `p_posts` (
  `post_id` int(11) NOT NULL auto_increment,
  `post_user` int(11) NOT NULL,
  `post_category` int(4) NOT NULL,
  `post_title` varchar(60) NOT NULL,
  `post_body` text NOT NULL,
  `post_date` int(10) NOT NULL,
  `post_tags` varchar(128) NOT NULL,
  `post_puntos` int(11) unsigned NOT NULL default '0',
  `post_comments` int(11) NOT NULL,
  `post_seguidores` int(11) NOT NULL,
  `post_shared` int(11) NOT NULL,
  `post_favoritos` int(11) NOT NULL,
  `post_cache` int(10) NOT NULL,
  `post_hits` int(11) NOT NULL default '0',
  `post_ip` varchar(15) NOT NULL,
  `post_private` int(1) NOT NULL default '0',
  `post_block_comments` int(1) NOT NULL default '0',
  `post_sponsored` int(1) NOT NULL default '0',
  `post_sticky` int(1) NOT NULL default '0',
  `post_smileys` int(1) NOT NULL,
  `post_visitantes` int(1) NOT NULL default '0',
  `post_status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`post_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `p_posts`
-- 

INSERT INTO `p_posts` VALUES (2, 1, 1, 'Causa Ciccones - Garcas de mierdas impresores de billete', '[size=18][b]El Frente para la Victoria impuso su mayoría y obtuvo 44 votos a favor. La UCR había pedido la intervención de la Auditoría General, pero el oficialismo no aceptó. Boudou, que presidió casi toda la sesión, fue blanco de críticas opositoras\r\n[/b][/size]\r\n\r\nTras casi 7 horas de debate, la Cámara alta dio el primer paso para la expropiación de la ex Ciccone Calcográfica. Con 44 votos a favor y 20 en contra –en su mayoría de la UCR–, el Frente para la Victoria dio media sanción al proyecto girado por el Poder Ejecutivo. \r\n\r\nEl senador Gerardo Morales solicitó segundos antes de la votación que se permitiera el ingreso de la Auditoría General de la Nación –tal como había sucedido con YPF–, pedido que fue desechado por el presidente del bloque kirchnerista, Miguel Pichetto. \r\n\r\nEl debate estuvo presidido por el vicepresidente, Amado Boudou, que sólo se ausentó una hora del recinto para almorzar junto a sus colaboradores de confianza. \r\n\r\nEl ex ministro de Economía, investigado en la causa que analiza supuestos beneficios estatales para levantar la quiebra de la ex Ciccone, fue blanco de las críticas de la oposición. \r\n\r\nEl presidente del bloque de la UCR, Luis Naidenoff, y el jujeño Morales fueron los que elevaron los discursos más duros y se trenzaron en las ya habituales discusiones con Aníbal Fernández. \r\n\r\nPichetto fue el encargado de cerrar la discusión y de aclarar que muchas de las cosas que se habían dicho durante la sesión no eran ciertas. Es más, les pidió &quot;seriedad&quot; a sus colegas y aclaró que la única causa abierta que existe contra Boudou es para invesigar su patrimonio. \r\n\r\nTras la media sanción, el proyecto de ley será girado a la Cámara de Diputados, donde el kirchnerismo dio muestras de su interés por acelerar el tratamiento. Para ello ya tiene agendada la realización de una sesión especial para sancionar el tema el miércoles de la semana próxima.\r\n\r\nEn ese marco, organizó un plenario de las comisiones de Asuntos Constitucionales, Presupuesto y de Legislación General, para el martes a las 12.\r\n\r\nLa idea es conseguir dictamen de las comisiones el mismo martes y llevar el proyecto al recinto al otro día en la referida sesión especial, a partir de la 11:30.\r\n\r\nRepercusiones tras el debate\r\n\r\nEl senador kirchnerista Aníbal Fernández consideró que &quot;para una expropiación no es importante saber quiénes son los dueños&quot; y sostuvo que &quot;la indemnización será en función de lo que determine el tribunal de tasaciones&quot;.\r\n\r\n&quot;Una vez que se determine el patrimonio neto, compararemos con la deuda que tiene con la AFIP&quot;, agregó al respecto.\r\n\r\nEn cuanto a lo ocurrido con el vicepresidente Amado Boudou, quien fue criticado por legisladores de la oposición, Fernández afirmó que &quot;nadie pidió la inmunidad de nadie&quot;.\r\n\r\n&quot;Aca hubo una vocación de encarajinar (sic) la situación. El vicepresidente no tiene ninguna causa que tenga que ver con Ciccone. Tiene una sobre su patrimonio y punto. Iban a tratar de enrostrar esto, pero no lo permitimos&quot;, precisó el ex jefe de Gabinete.\r\n', 1345156583, 'causa, ciccones, garcas, mierdas, billete falsos', 0, 0, 0, 0, 0, 1345160970, 0, '127.0.0.1', 0, 0, 0, 0, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `p_votos`
-- 

CREATE TABLE `p_votos` (
  `voto_id` int(11) NOT NULL auto_increment,
  `tid` int(11) NOT NULL,
  `tuser` int(11) NOT NULL,
  `cant` int(11) NOT NULL,
  `type` int(1) NOT NULL default '1',
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`voto_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `p_votos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_actividad`
-- 

CREATE TABLE `u_actividad` (
  `ac_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `obj_uno` int(11) NOT NULL,
  `obj_dos` int(11) NOT NULL,
  `ac_type` int(2) NOT NULL,
  `ac_date` int(10) NOT NULL,
  PRIMARY KEY  (`ac_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `u_actividad`
-- 

INSERT INTO `u_actividad` VALUES (1, 1, 1, 0, 5, 1345156406);
INSERT INTO `u_actividad` VALUES (2, 1, 2, 0, 1, 1345156583);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_avisos`
-- 

CREATE TABLE `u_avisos` (
  `av_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `av_subject` varchar(24) NOT NULL,
  `av_body` text NOT NULL,
  `av_date` int(10) NOT NULL,
  `av_read` int(1) NOT NULL default '0',
  `av_type` int(1) NOT NULL default '0',
  PRIMARY KEY  (`av_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_avisos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_bloqueos`
-- 

CREATE TABLE `u_bloqueos` (
  `bid` int(11) NOT NULL auto_increment,
  `b_user` int(11) NOT NULL,
  `b_auser` int(11) NOT NULL,
  PRIMARY KEY  (`bid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_bloqueos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_follows`
-- 

CREATE TABLE `u_follows` (
  `follow_id` int(11) NOT NULL auto_increment,
  `f_user` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `f_type` int(1) NOT NULL,
  `f_date` int(10) NOT NULL,
  PRIMARY KEY  (`follow_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_follows`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_mensajes`
-- 

CREATE TABLE `u_mensajes` (
  `mp_id` int(11) NOT NULL auto_increment,
  `mp_to` int(11) NOT NULL,
  `mp_from` int(11) NOT NULL,
  `mp_answer` int(1) NOT NULL default '0',
  `mp_read_to` int(1) NOT NULL default '0',
  `mp_read_from` int(1) NOT NULL default '1',
  `mp_read_mon_to` int(1) NOT NULL default '0',
  `mp_read_mon_from` int(1) NOT NULL default '1',
  `mp_del_to` int(1) NOT NULL default '0',
  `mp_del_from` int(1) NOT NULL default '0',
  `mp_subject` varchar(50) NOT NULL,
  `mp_preview` varchar(75) NOT NULL,
  `mp_date` int(10) NOT NULL,
  PRIMARY KEY  (`mp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_mensajes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_miembros`
-- 

CREATE TABLE `u_miembros` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(16) NOT NULL,
  `user_password` varchar(32) NOT NULL,
  `user_email` varchar(35) NOT NULL,
  `user_rango` int(3) NOT NULL default '3',
  `user_puntos` int(6) unsigned NOT NULL default '0',
  `user_posts` int(11) NOT NULL,
  `user_comentarios` int(11) NOT NULL,
  `user_seguidores` int(11) NOT NULL,
  `user_cache` int(10) NOT NULL,
  `user_puntosxdar` int(2) unsigned NOT NULL default '0',
  `user_bad_hits` int(2) unsigned NOT NULL default '0',
  `user_nextpuntos` int(10) NOT NULL default '0',
  `user_registro` int(10) NOT NULL default '0',
  `user_lastlogin` int(10) NOT NULL default '0',
  `user_lastactive` int(10) NOT NULL default '0',
  `user_lastpost` int(10) NOT NULL default '0',
  `user_last_ip` varchar(15) NOT NULL default '0',
  `user_name_changes` int(11) NOT NULL default '3',
  `user_activo` int(1) NOT NULL default '0',
  `user_baneado` int(1) NOT NULL default '0',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- Volcar la base de datos para la tabla `u_miembros`
-- 

INSERT INTO `u_miembros` VALUES (1, 'admin', '86f3059b228c8acf99e69734b6bb32cc', 'cyber.root@outlook.com', 1, 0, -1, 1, 0, 0, 50, 0, 1345172400, 1345155469, 1345157168, 1345164620, 1345156583, '127.0.0.1', 3, 1, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_monitor`
-- 

CREATE TABLE `u_monitor` (
  `not_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `obj_user` int(11) NOT NULL,
  `obj_uno` int(11) NOT NULL default '0',
  `obj_dos` int(11) NOT NULL default '0',
  `obj_tres` int(11) NOT NULL default '0',
  `not_type` int(2) NOT NULL,
  `not_date` int(10) NOT NULL,
  `not_total` int(2) NOT NULL default '1',
  `not_menubar` int(1) NOT NULL default '2',
  `not_monitor` int(1) NOT NULL default '1',
  PRIMARY KEY  (`not_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_monitor`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_muro`
-- 

CREATE TABLE `u_muro` (
  `pub_id` int(11) NOT NULL auto_increment,
  `p_user` int(11) NOT NULL,
  `p_user_pub` int(11) NOT NULL,
  `p_date` int(10) NOT NULL,
  `p_comments` int(4) NOT NULL default '0',
  `p_body` text NOT NULL,
  `p_likes` int(4) NOT NULL default '0',
  `p_type` int(1) NOT NULL,
  `p_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`pub_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_muro`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_muro_adjuntos`
-- 

CREATE TABLE `u_muro_adjuntos` (
  `adj_id` int(11) NOT NULL auto_increment,
  `pub_id` int(11) NOT NULL,
  `a_title` varchar(100) NOT NULL,
  `a_url` text NOT NULL,
  `a_img` text NOT NULL,
  `a_desc` text NOT NULL,
  PRIMARY KEY  (`adj_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_muro_adjuntos`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_muro_comentarios`
-- 

CREATE TABLE `u_muro_comentarios` (
  `cid` int(11) NOT NULL auto_increment,
  `pub_id` int(11) NOT NULL,
  `c_user` int(11) NOT NULL,
  `c_date` int(10) NOT NULL,
  `c_body` text NOT NULL,
  `c_likes` int(4) NOT NULL,
  `c_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_muro_comentarios`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_muro_likes`
-- 

CREATE TABLE `u_muro_likes` (
  `like_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `obj_id` int(11) NOT NULL,
  `obj_type` int(1) NOT NULL,
  PRIMARY KEY  (`like_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_muro_likes`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_nicks`
-- 

CREATE TABLE `u_nicks` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `name_1` varchar(15) NOT NULL,
  `name_2` varchar(15) NOT NULL,
  `hash` varchar(32) NOT NULL,
  `time` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  `estado` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_nicks`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_perfil`
-- 

CREATE TABLE `u_perfil` (
  `user_id` int(11) NOT NULL,
  `user_dia` int(2) NOT NULL,
  `user_mes` int(2) NOT NULL,
  `user_ano` int(4) NOT NULL,
  `user_pais` varchar(2) NOT NULL,
  `user_estado` int(2) NOT NULL default '1',
  `user_sexo` int(1) NOT NULL default '1',
  `user_firma` text NOT NULL,
  `p_nombre` varchar(32) NOT NULL,
  `p_avatar` int(1) NOT NULL default '0',
  `p_mensaje` varchar(60) NOT NULL,
  `p_sitio` varchar(60) NOT NULL,
  `p_socials` text NOT NULL,
  `p_gustos` varchar(71) NOT NULL default 'a:5:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;}',
  `p_estado` int(1) NOT NULL default '0',
  `p_hijos` int(1) NOT NULL default '0',
  `p_vivo` int(1) NOT NULL default '0',
  `p_altura` int(3) NOT NULL default '0',
  `p_peso` int(3) NOT NULL default '0',
  `p_pelo` int(1) NOT NULL default '0',
  `p_ojos` int(1) NOT NULL default '0',
  `p_fisico` int(1) NOT NULL default '0',
  `p_dieta` int(1) NOT NULL default '0',
  `p_tengo` varchar(60) NOT NULL default 'a:2:{i:0;i:0;i:1;i:0;}',
  `p_fumo` int(1) NOT NULL default '0',
  `p_tomo` int(1) NOT NULL default '0',
  `p_estudios` int(1) NOT NULL default '0',
  `p_idiomas` varchar(102) NOT NULL default 'a:7:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;}',
  `p_profesion` varchar(32) NOT NULL,
  `p_empresa` varchar(32) NOT NULL,
  `p_sector` int(2) NOT NULL default '0',
  `p_ingresos` int(1) NOT NULL default '0',
  `p_int_prof` text NOT NULL,
  `p_hab_prof` text NOT NULL,
  `p_intereses` text NOT NULL,
  `p_hobbies` text NOT NULL,
  `p_tv` text NOT NULL,
  `p_musica` text NOT NULL,
  `p_deportes` text NOT NULL,
  `p_libros` text NOT NULL,
  `p_peliculas` text NOT NULL,
  `p_comida` text NOT NULL,
  `p_heroes` text NOT NULL,
  `p_configs` varchar(100) NOT NULL default 'a:3:{s:1:"m";s:1:"5";s:2:"mf";i:5;s:3:"rmp";s:1:"5";}',
  `p_total` varchar(54) NOT NULL default 'a:6:{i:0;i:5;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}',
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `u_perfil`
-- 

INSERT INTO `u_perfil` VALUES (1, 0, 0, 0, '', 1, 1, '', '', 0, '', '', '', 'a:5:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;}', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'a:2:{i:0;i:0;i:1;i:0;}', 0, 0, 0, 'a:7:{i:0;i:0;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;i:6;i:0;}', '', '', 0, 0, '', '', '', '', '', '', '', '', '', '', '', 'a:3:{s:1:"m";s:1:"5";s:2:"mf";i:5;s:3:"rmp";s:1:"5";}', 'a:6:{i:0;i:5;i:1;i:0;i:2;i:0;i:3;i:0;i:4;i:0;i:5;i:0;}');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_portal`
-- 

CREATE TABLE `u_portal` (
  `user_id` int(11) NOT NULL,
  `last_posts_visited` text NOT NULL,
  `last_posts_shared` text NOT NULL,
  `last_posts_cats` text NOT NULL,
  `c_monitor` text NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `u_portal`
-- 

INSERT INTO `u_portal` VALUES (1, 'a:2:{i:0;s:1:"1";i:1;s:1:"2";}', '', '', '');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_rangos`
-- 

CREATE TABLE `u_rangos` (
  `rango_id` int(3) NOT NULL auto_increment,
  `r_name` varchar(32) NOT NULL,
  `r_color` varchar(6) NOT NULL default '171717',
  `r_image` varchar(32) NOT NULL default 'new.png',
  `r_cant` int(5) NOT NULL,
  `r_allows` varchar(1000) NOT NULL,
  `r_type` int(1) NOT NULL default '0',
  PRIMARY KEY  (`rango_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- Volcar la base de datos para la tabla `u_rangos`
-- 

INSERT INTO `u_rangos` VALUES (1, 'Administrador', 'D6030B', 'rosette.png', 0, 'a:4:{s:4:"suad";s:2:"on";s:4:"goaf";s:1:"5";s:5:"gopfp";s:2:"20";s:5:"gopfd";s:2:"50";}', 0);
INSERT INTO `u_rangos` VALUES (2, 'Moderador', 'ff9900', 'shield.png', 0, 'a:4:{s:4:"sumo";s:2:"on";s:4:"goaf";s:2:"15";s:5:"gopfp";s:2:"18";s:5:"gopfd";s:2:"30";}', 0);
INSERT INTO `u_rangos` VALUES (3, 'Novato', '171717', 'new.png', 0, 'a:12:{s:4:"godp";s:2:"on";s:4:"gopp";s:2:"on";s:5:"gopcp";s:2:"on";s:5:"govpp";s:2:"on";s:5:"govpn";s:2:"on";s:5:"goepc";s:2:"on";s:5:"godpc";s:2:"on";s:4:"gopf";s:2:"on";s:5:"gopcf";s:2:"on";s:4:"goaf";s:2:"20";s:5:"gopfp";s:1:"5";s:5:"gopfd";s:1:"5";}', 0);
INSERT INTO `u_rangos` VALUES (4, 'New Full User', '0198E7', 'star_bronze_3.png', 50, 'a:12:{s:4:"godp";s:2:"on";s:4:"gopp";s:2:"on";s:5:"gopcp";s:2:"on";s:5:"govpp";s:2:"on";s:5:"govpn";s:2:"on";s:5:"goepc";s:2:"on";s:5:"godpc";s:2:"on";s:4:"gopf";s:2:"on";s:5:"gopcf";s:2:"on";s:4:"goaf";s:2:"20";s:5:"gopfp";s:2:"10";s:5:"gopfd";s:2:"10";}', 1);
INSERT INTO `u_rangos` VALUES (5, 'Full User', '00ccff', 'star_silver_3.png', 70, 'a:12:{s:4:"godp";s:2:"on";s:4:"gopp";s:2:"on";s:5:"gopcp";s:2:"on";s:5:"govpp";s:2:"on";s:5:"govpn";s:2:"on";s:5:"goepc";s:2:"on";s:5:"godpc";s:2:"on";s:4:"gopf";s:2:"on";s:5:"gopcf";s:2:"on";s:4:"goaf";s:2:"20";s:5:"gopfp";s:2:"12";s:5:"gopfd";s:2:"20";}', 1);
INSERT INTO `u_rangos` VALUES (6, 'Great User', '01A021', 'star_gold_3.png', 0, 'a:12:{s:4:"godp";s:2:"on";s:4:"gopp";s:2:"on";s:5:"gopcp";s:2:"on";s:5:"govpp";s:2:"on";s:5:"govpn";s:2:"on";s:5:"goepc";s:2:"on";s:5:"godpc";s:2:"on";s:4:"gopf";s:2:"on";s:5:"gopcf";s:2:"on";s:4:"goaf";s:2:"20";s:5:"gopfp";s:2:"11";s:5:"gopfd";s:2:"15";}', 0);
INSERT INTO `u_rangos` VALUES (7, 'Gold User', 'cc6600', 'asterisk_yellow.png', 120, 'a:12:{s:4:"godp";s:2:"on";s:4:"gopp";s:2:"on";s:5:"gopcp";s:2:"on";s:5:"govpp";s:2:"on";s:5:"govpn";s:2:"on";s:5:"goepc";s:2:"on";s:5:"godpc";s:2:"on";s:4:"gopf";s:2:"on";s:5:"gopcf";s:2:"on";s:4:"goaf";s:2:"20";s:5:"gopfp";s:2:"12";s:5:"gopfd";s:2:"25";}', 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_respuestas`
-- 

CREATE TABLE `u_respuestas` (
  `mr_id` int(11) NOT NULL auto_increment,
  `mp_id` int(11) NOT NULL,
  `mr_from` int(11) NOT NULL,
  `mr_body` text NOT NULL,
  `mr_ip` varchar(15) NOT NULL,
  `mr_date` int(10) NOT NULL,
  PRIMARY KEY  (`mr_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_respuestas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_sessions`
-- 

CREATE TABLE `u_sessions` (
  `session_id` varchar(32) NOT NULL,
  `session_user_id` int(11) unsigned NOT NULL default '0',
  `session_ip` varchar(40) NOT NULL,
  `session_time` int(10) unsigned NOT NULL default '0',
  `session_autologin` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`session_id`),
  KEY `session_user_id` (`session_user_id`),
  KEY `session_time` (`session_time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `u_sessions`
-- 

INSERT INTO `u_sessions` VALUES ('3fee4712a001e4df76d2fa85f178dcab', 1, '127.0.0.1', 1345156737, 1);
INSERT INTO `u_sessions` VALUES ('49fccc698e708f0a8f0ce9b24ea1140c', 1, '127.0.0.1', 1345156981, 1);
INSERT INTO `u_sessions` VALUES ('761e70bb1e7c5f4bda77367fd1fcd4de', 1, '127.0.0.1', 1345164438, 1);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `u_suspension`
-- 

CREATE TABLE `u_suspension` (
  `susp_id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `susp_causa` text NOT NULL,
  `susp_date` int(10) NOT NULL,
  `susp_termina` int(10) NOT NULL,
  `susp_mod` int(11) NOT NULL,
  `susp_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`susp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `u_suspension`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_afiliados`
-- 

CREATE TABLE `w_afiliados` (
  `aid` int(11) NOT NULL auto_increment,
  `a_titulo` varchar(35) NOT NULL,
  `a_url` varchar(40) NOT NULL,
  `a_banner` varchar(100) NOT NULL,
  `a_descripcion` varchar(200) NOT NULL,
  `a_sid` int(11) NOT NULL default '0',
  `a_hits_in` int(11) NOT NULL default '0',
  `a_hits_out` int(11) NOT NULL default '0',
  `a_date` int(10) NOT NULL,
  `a_active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`aid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_afiliados`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_badwords`
-- 

CREATE TABLE `w_badwords` (
  `wid` int(11) NOT NULL auto_increment,
  `word` varchar(250) NOT NULL,
  `swop` varchar(250) NOT NULL,
  `method` int(1) NOT NULL,
  `type` int(1) NOT NULL,
  `author` int(11) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`wid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_badwords`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_blacklist`
-- 

CREATE TABLE `w_blacklist` (
  `id` int(11) NOT NULL auto_increment,
  `type` int(1) NOT NULL,
  `value` varchar(50) NOT NULL,
  `reason` varchar(120) NOT NULL,
  `author` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_blacklist`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_configuracion`
-- 

CREATE TABLE `w_configuracion` (
  `tscript_id` int(11) NOT NULL,
  `titulo` varchar(24) NOT NULL,
  `slogan` varchar(32) NOT NULL,
  `url` tinytext NOT NULL,
  `email` varchar(60) NOT NULL,
  `banner` varchar(100) NOT NULL,
  `tema_id` int(11) NOT NULL,
  `ads_300` text NOT NULL,
  `ads_468` text NOT NULL,
  `ads_160` text NOT NULL,
  `ads_728` text NOT NULL,
  `ads_search` varchar(50) NOT NULL,
  `chat_id` varchar(20) NOT NULL,
  `xat_id` varchar(20) NOT NULL,
  `c_last_active` int(2) NOT NULL,
  `c_allow_sess_ip` int(1) NOT NULL,
  `c_count_guests` int(1) NOT NULL,
  `c_reg_active` int(1) NOT NULL,
  `c_reg_activate` int(1) NOT NULL,
  `c_reg_rango` int(5) NOT NULL,
  `c_met_welcome` int(1) NOT NULL,
  `c_message_welcome` varchar(500) NOT NULL,
  `c_fotos_private` int(11) NOT NULL,
  `c_hits_guest` int(1) NOT NULL,
  `c_keep_points` int(1) NOT NULL,
  `c_allow_points` int(11) NOT NULL,
  `c_allow_edad` int(11) NOT NULL,
  `c_max_posts` int(2) NOT NULL,
  `c_max_com` int(3) NOT NULL,
  `c_max_nots` int(3) NOT NULL,
  `c_max_acts` int(3) NOT NULL,
  `c_newr_type` int(11) NOT NULL,
  `c_allow_sump` int(11) NOT NULL,
  `c_allow_firma` int(1) NOT NULL,
  `c_allow_upload` int(1) NOT NULL,
  `c_allow_portal` int(1) NOT NULL,
  `c_allow_live` int(1) NOT NULL,
  `c_see_mod` int(1) NOT NULL,
  `c_stats_cache` int(7) NOT NULL default '15',
  `c_desapprove_post` int(1) NOT NULL,
  `offline` int(1) NOT NULL default '0',
  `offline_message` varchar(255) NOT NULL,
  `version` varchar(16) NOT NULL,
  `version_code` varchar(16) NOT NULL,
  PRIMARY KEY  (`tscript_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `w_configuracion`
-- 

INSERT INTO `w_configuracion` VALUES (1, 'Social Posting', 'Best Posting', 'http://localhost/phpost', 'cyber.root@gmail.com', 'http://i.imgur.com/2nEr3s.png?1', 4, '<a href="http://www.phpost.net/" target="_blank"><img src="/themes/default/images/ad300.gif"/></a>', '<a href="http://www.phpost.net/" target="_blank"><img src="/themes/default/images/ad468.png"/></a>', '<a href="http://www.phpost.net/" target="_blank"><img src="/themes/default/images/ad160.gif"/></a>', '<a href="http://www.phpost.net/" target="_blank"><img src="/themes/default/images/ad728.gif"/></a>', 'partner-pub-5535725517227860:7900040286', '', '0', 15, 1, 0, 1, 1, 3, 0, 'Hola [usuario], [welcome] a [b][web][/b].', 0, 0, 0, 0, 18, 50, 50, 99, 99, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 'Estamos en mantenimiento', 'Risus', 'risus');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_contacts`
-- 

CREATE TABLE `w_contacts` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL,
  `user_email` varchar(50) NOT NULL,
  `time` int(15) NOT NULL,
  `type` int(1) NOT NULL,
  `hash` varchar(32) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_contacts`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_denuncias`
-- 

CREATE TABLE `w_denuncias` (
  `did` int(11) NOT NULL auto_increment,
  `obj_id` int(11) NOT NULL,
  `d_user` int(11) NOT NULL,
  `d_razon` int(2) NOT NULL,
  `d_extra` text NOT NULL,
  `d_total` int(1) NOT NULL default '1',
  `d_type` int(1) NOT NULL,
  `d_date` int(10) NOT NULL,
  PRIMARY KEY  (`did`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_denuncias`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_historial`
-- 

CREATE TABLE `w_historial` (
  `id` int(11) NOT NULL auto_increment,
  `pofid` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  `action` int(1) NOT NULL,
  `mod` int(11) NOT NULL default '0',
  `reason` text NOT NULL,
  `date` int(11) NOT NULL,
  `mod_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_historial`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_medallas`
-- 

CREATE TABLE `w_medallas` (
  `medal_id` int(11) NOT NULL auto_increment,
  `m_autor` int(11) NOT NULL,
  `m_title` varchar(25) NOT NULL,
  `m_description` varchar(120) NOT NULL,
  `m_image` varchar(120) NOT NULL,
  `m_cant` int(11) NOT NULL,
  `m_type` int(1) NOT NULL,
  `m_cond_user` int(11) NOT NULL,
  `m_cond_user_rango` int(11) NOT NULL,
  `m_cond_post` int(11) NOT NULL,
  `m_cond_foto` int(11) NOT NULL,
  `m_date` int(11) NOT NULL,
  `m_total` int(11) NOT NULL,
  PRIMARY KEY  (`medal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_medallas`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_medallas_assign`
-- 

CREATE TABLE `w_medallas_assign` (
  `id` int(11) NOT NULL auto_increment,
  `medal_id` int(11) NOT NULL,
  `medal_for` int(11) NOT NULL,
  `medal_date` int(11) NOT NULL,
  `medal_ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_medallas_assign`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_noticias`
-- 

CREATE TABLE `w_noticias` (
  `not_id` int(11) NOT NULL auto_increment,
  `not_body` text NOT NULL,
  `not_autor` int(11) NOT NULL,
  `not_date` int(10) NOT NULL,
  `not_active` int(1) NOT NULL default '0',
  PRIMARY KEY  (`not_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `w_noticias`
-- 


-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_stats`
-- 

CREATE TABLE `w_stats` (
  `stats_no` int(1) NOT NULL,
  `stats_max_online` int(11) NOT NULL,
  `stats_max_time` int(10) NOT NULL,
  `stats_time` int(10) NOT NULL,
  `stats_time_cache` int(10) NOT NULL,
  `stats_time_foundation` int(11) NOT NULL,
  `stats_time_upgrade` int(11) NOT NULL,
  `stats_miembros` int(11) NOT NULL,
  `stats_posts` int(11) NOT NULL,
  `stats_fotos` int(11) NOT NULL,
  `stats_comments` int(11) NOT NULL,
  `stats_foto_comments` int(11) NOT NULL,
  PRIMARY KEY  (`stats_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- Volcar la base de datos para la tabla `w_stats`
-- 

INSERT INTO `w_stats` VALUES (1, 1, 1345155828, 1345164000, 1345164000, 1345155469, 1345155469, 1, 1, 0, 0, 0);

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_temas`
-- 

CREATE TABLE `w_temas` (
  `tid` int(11) NOT NULL auto_increment,
  `t_name` tinytext NOT NULL,
  `t_url` tinytext NOT NULL,
  `t_path` tinytext NOT NULL,
  `t_copy` tinytext NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- Volcar la base de datos para la tabla `w_temas`
-- 

INSERT INTO `w_temas` VALUES (1, 'PHPost Default', '/themes/default', 'default', 'Taringa!');
INSERT INTO `w_temas` VALUES (4, 'State MegaErick', 'http://localhost/phpost/themes/state_mega', 'state_mega', 'MegaEricks Designs');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `w_visitas`
-- 

CREATE TABLE `w_visitas` (
  `id` int(11) NOT NULL auto_increment,
  `user` int(11) NOT NULL,
  `for` int(11) NOT NULL,
  `type` int(1) NOT NULL,
  `date` int(11) NOT NULL,
  `ip` varchar(15) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Volcar la base de datos para la tabla `w_visitas`
-- 

INSERT INTO `w_visitas` VALUES (1, 1, 1, 2, 1345159759, '127.0.0.1');
INSERT INTO `w_visitas` VALUES (2, 1, 2, 2, 1345160970, '127.0.0.1');
